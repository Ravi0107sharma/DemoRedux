import { createStore } from 'redux'

function fun1(state: string, action: any) {
    switch (action.type) {
        case 'ADD_TODO':
            state = action.text;
            return state;
        default:
            return state
    }
}

export const store = createStore(fun1, "text1");

store.dispatch({
    type: 'ADD_TODO',
    text: 'Read the docs'
});
store.dispatch({
    type: 'ADD_TODO',
    text: 'Read the docs1'
});

console.log(store.getState())



export default store;