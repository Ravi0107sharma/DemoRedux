export default function()
{
    return [
       {
        id: 1,
        first: "Ravi",
        Last: "Sharma"
       },

       {
        id: 2,
        first: "Abc",
        Last: "Sharma"
       },
    ]

}

